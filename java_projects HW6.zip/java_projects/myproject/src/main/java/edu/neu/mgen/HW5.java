package edu.neu.mgen;

import java.util.ArrayList;

public class HW5 {
    public static void main(String[] args) {
        //Q3
        int x=10;
        int y=25;
        System.out.println(Math.max(x,y));
        System.out.println(Math.min(x,y));
        System.out.println(Math.sqrt(x));
        System.out.println(Math.sqrt(y));
        //Q4
    String str="Oakland";
        System.out.println(str.length());
        char result=str.charAt(2);
        System.out.println(result);
        System.out.println(str.substring(3,7));
        System.out.println(str.toUpperCase());
        //Q5
        int[] abc = {1, 3, 5, 2, 5};
        System.out.println(abc.length);
        System.out.println(abc[abc.length-1]);
        //Q6
        ArrayList<String>city= new ArrayList<>();
        city.add("Austin");
        city.add("Houston");
        city.add("Oakland");
        city.add("Paris");
        city.add("San Francisco");
        city.add("Seattle");
        System.out.println(city);
        city.remove("Paris");
        System.out.println(city);
}}
