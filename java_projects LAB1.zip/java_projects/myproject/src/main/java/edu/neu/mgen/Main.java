package edu.neu.mgen;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Declare and initialize variables of different types
        int intVar1 = 41;
        int intVar2 = 17;
        long longVar1 = 1234567890L;
        long longVar2 = 9876543210L;
        double doubleVar1 = 3.14159;
        double doubleVar2 = 2.71828;
        boolean boolVar1 = true;
        boolean boolVar2 = false;
        char charVar1 = 'A';
        char charVar2 = 'B';

        // Convert initialized variables of type "int" to "long"
        longVar1 = intVar1;
        longVar2 = intVar2;

        // Convert initialized variables of type "long" to "int"
        intVar1 = (int) longVar1;
        intVar2 = (int) longVar2;

        // Input values for variables from the terminal
        System.out.print("Enter a new value for intVar1: ");
        intVar1 = scanner.nextInt();
        System.out.print("Enter a new value for intVar2: ");
        intVar2 = scanner.nextInt();
        System.out.print("Enter a new value for longVar1: ");
        longVar1 = scanner.nextLong();
        System.out.print("Enter a new value for longVar2: ");
        longVar2 = scanner.nextLong();
        System.out.print("Enter a new value for doubleVar1: ");
        doubleVar1 = scanner.nextDouble();
        System.out.print("Enter a new value for doubleVar2: ");
        doubleVar2 = scanner.nextDouble();
        System.out.print("Enter a new value for boolVar1 (true or false): ");
        boolVar1 = scanner.nextBoolean();
        System.out.print("Enter a new value for boolVar2 (true or false): ");
        boolVar2 = scanner.nextBoolean();
        System.out.print("Enter a new value for charVar1: ");
        charVar1 = scanner.next().charAt(0);
        System.out.print("Enter a new value for charVar2: ");
        charVar2 = scanner.next().charAt(0);

        // Perform arithmetic and logical operations
        System.out.println("Arithmetic and Logical Operations:");
        System.out.println("intVar1 + intVar2 = " + (intVar1 + intVar2));
        System.out.println("longVar1 - longVar2 = " + (longVar1 - longVar2));
        System.out.println("doubleVar1 * doubleVar2 = " + (doubleVar1 * doubleVar2));
        System.out.println("boolVar1 && boolVar2 = " + (boolVar1 && boolVar2));
        System.out.println("charVar1 == charVar2: " + (charVar1 == charVar2));

        scanner.close();
    }
}
